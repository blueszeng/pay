local CardGroup = class("CardGroup")
local Card = require "model.vos.Card"
local CardType = MJ.CardType
local Tool = Utils.Tool
local HeapType = MJ.HeapType
local DOWN = MJ.DOWN
local UP = MJ.UP
local OUT = MJ.OUT
local _addingHis = false
function CardGroup:ctor(handCrad, parent, his_parent, cardType, idx, gui, isRecord)
    self.gui = gui
    self.cardType = cardType
    self.his_parent = his_parent
    self.idx = idx
    self.parent = parent
    Tool.removeChildren(self.his_parent.transform)
    Tool.removeChildren(self.parent.transform)
    self.handCrad = handCrad
    self._cards = {}
    self._his = {}
    self._heapsMing = {}
    self._heapsAn = {}
    self.isRecord = isRecord --是否录像
    self:sortCard()
    self:_init()
end

function CardGroup:clear()
    if not self.his_parent then return end
    if not self.parent then return end
    Tool.removeChildren(self.his_parent.transform)
    Tool.removeChildren(self.parent.transform)
    self.handCrad = nil
    self._cards = nil
    self._his = nil
    self._heapsMing = nil
    self._heapsAn = nil
    self.parent = nil
    self.his_parent = nil
end

function CardGroup:_init(_bottom)
    local gui = self.gui
    if not self.handCrad then return end
    local heap = self.handCrad.heap
    local parent = self.parent
    local item, val, tp, _card_obj
    local pos = 0
    local cardNum = 0
    local ming_index = 1
    local an_index = 1
    local up = self.cardType << UP
    local down = self.cardType << DOWN

    self:HideAllHeap()

    for i = 1, #heap do
        item = heap[i]
        tp = item.t
        val = item.v
        for j = 1,3 do
            cardNum = cardNum + 1
            if tp == HeapType.AnGang then
                _card_obj = self._heapsAn[an_index]
                if _card_obj then
                    _card_obj:update(val,down)
                else
                    _card_obj = Card:create(val,down,parent)
                    self._heapsAn[an_index] = _card_obj
                end
                an_index = an_index + 1
            else
                _card_obj = self._heapsMing[ming_index]
                if _card_obj then
                    _card_obj:update(val,up)
                else
                    _card_obj = Card:create(val,up,parent)
                    self._heapsMing[ming_index] = _card_obj
                end
                ming_index = ming_index + 1
            end
            _card_obj:setCardPos(pos)            
            _card_obj:isGui(gui)
            pos = pos + _card_obj:getDistance()
        end
        if tp ~= HeapType.Peng then
            -- cardNum = cardNum + 1
            _card_obj = self._heapsMing[ming_index]
            if _card_obj then
                _card_obj:update(val,up)
            else
                _card_obj = Card:create(val,up,parent)
                self._heapsMing[ming_index] = _card_obj
            end
            ming_index = ming_index + 1
            _card_obj:setHeapCardPos(pos,tp == HeapType.AnGang)
        end
        if self.cardType == CardType.Bottom then
            pos = pos + 5
        elseif  self.cardType == CardType.Right then
            pos = pos + 16
        elseif  self.cardType == CardType.Top then
            pos = pos - 3
        elseif  self.cardType == CardType.Left then
            pos = pos - 10
            if self.isRecord then 
                pos = pos - 5
            end
        end
    
    end
    local cards = self.handCrad.card
    local card
    local card_num = 0
    if not self.isRecord then
        local tt = type(cards)
        if CardType.Bottom == self.cardType then
            if tt ~= "table" then
                self.handCrad.card = self.last_card_table or {}
                cards = self.handCrad.card
            end
            self.last_card_table = cards
            pos = pos + 5
            card_num = #cards
            for i = 1, card_num do
                card = cards[i]
                _card_obj = self._cards[i]
                if _card_obj then
                    _card_obj:update(card,self.cardType)
                else
                    _card_obj = Card:create(card,self.cardType,parent)
                    self._cards[i] = _card_obj
                end
                _card_obj:setCardPos(pos)
                _card_obj:isGui(gui)
                pos = pos + _card_obj:getDistance()

                cardNum = cardNum + 1
                if cardNum == 13 then 
                    pos = pos + 30
                end
            end
        else
            if CardType.Top == self.cardType then
                pos = pos - 5
            end
            if tt ~= "number" then 
                self.handCrad.card = self.last_card_num or 1
                cards = self.handCrad.card
                UnityEngine.Debug.LogError("类型出错 位置 " .. self.idx)
            end
            card_num = cards
            self.last_card_num = cards
            for i = 1, cards do
                _card_obj = self._cards[i]
                if _card_obj then
                    _card_obj:update(0,self.cardType)
                else
                    _card_obj = Card:create(0,self.cardType,parent)
                    self._cards[i] = _card_obj
                end
                _card_obj:setCardPos(pos)
                pos = pos + _card_obj:getDistance()
                cardNum = cardNum + 1
                if cardNum == 13 then 
                    if self.cardType == CardType.Bottom then
                        pos = pos + 30
                    elseif  self.cardType == CardType.Right then
                        pos = pos + 30
                    elseif  self.cardType == CardType.Top then
                        pos = pos - 25
                    elseif  self.cardType == CardType.Left then
                        pos = pos - 30
                    end
                end
            end
        end
    else
        if CardType.Top == self.cardType or self.cardType == CardType.Left then
            pos = pos - 5
        end
        if CardType.Bottom == self.cardType then
            pos = pos + 5
        end        
        card_num = #cards
        for i = 1, card_num do
            card = cards[i]
            _card_obj = self._cards[i]
            if _card_obj then
                if self.cardType == CardType.Bottom then
                    _card_obj:update(card,self.cardType)
                else
                    _card_obj:update(card,self.cardType << OUT)
                end                
            else
                if self.cardType == CardType.Bottom then
                    _card_obj = Card:create(card,self.cardType,parent)
                else
                    _card_obj = Card:create(card,self.cardType << OUT,parent)
                end 
                self._cards[i] = _card_obj
            end
            _card_obj:setCardPos(pos)
            _card_obj:isGui(gui)
            pos = pos + _card_obj:getDistance()

            cardNum = cardNum + 1
            if cardNum == 13 then 
                if self.cardType == CardType.Bottom then
                    pos = pos + 30
                elseif  self.cardType == CardType.Right then
                    pos = pos + 20
                elseif  self.cardType == CardType.Top then
                    pos = pos - 15
                elseif  self.cardType == CardType.Left then
                    pos = pos - 20
                end
            end
        end
    end
    --隐藏已出的牌
    for i = card_num + 1,#self._cards do
        self._cards[i]:remove()
    end
    if _bottom then return end
    
    local his = self.handCrad.his
    local h
    pos = 0
    local level = 0
    local count = self:getHisLineCount()
    parent = self.his_parent
    local tp = self.cardType << OUT
    
    for i = 1,#his do
        val = his[i]
        _card_obj = self._his[i]
        
        if _card_obj then
            _card_obj:update(val,tp)
        else
            _card_obj = Card:create(val,tp,parent)
            self._his[i] = _card_obj
        end
        
        _card_obj:setCardPos(pos,level)
        _card_obj:isGui(gui)
        pos = pos + _card_obj:getDistance()
        if i % count == 0 then
            level = level + 1
            pos = 0
        end
    end
    for i = #his + 1,#self._his do 
        _card_obj = self._his[i]
        if _card_obj then 
            _card_obj:remove()
        end
    end
end

function CardGroup:getHisPos(index)
    local level = 0
    local count = self:getHisLineCount()
    local len = #self.handCrad.his
    local last = self._his[len]
    if not last then 
        return 0,0
    end
    level = math.floor(index/count)
   
    return last:getDistance() * (index % count),level
end

---以出牌每行多少个
function CardGroup:getHisLineCount()
    if self.cardType == CardType.Bottom then
        return 11
    end
    return 8
end

function CardGroup:RemoveHis()
    local len = #self.handCrad.his
    self.handCrad.his[len] = nil
    local last = self._his[#self._his]
    if last then
        last:remove()
    end

    --如果在出版中删除前一个历史记录，需要标记出来，出完牌后删除。
    if self.cardType == CardType.Bottom then
        _addingHis = false
    end
end

--选择已出牌
function CardGroup:selectHisCard(data)
    local ret = data.select or false
    local val = data.val
    for i,v in ipairs(self._his) do 
        if not v.isRemove and v.id == val then 
            v:setSelected(ret)
        end
    end
end

function CardGroup:getLastCard(cards)
    for i = #cards,1,-1 do 
        local card = cards[i]
        if not card.isRemove then 
            return card
        end
    end
    return cards[#cards]
end

function CardGroup:getRectPos(card,node)
    local parent = card.transform.parent
    card.transform:SetParent(node.transform)
    local pivot = card.pivot
    local size = MJ.getSize(card.gameObject)
    MJ.setPos(card.gameObject,(pivot.x - 0.5) * size.width,(pivot.y - 0.5) * size.height)
    card.transform:SetParent(parent)
    return card.transform.position
end

function CardGroup:AddHis(val,node,card_ani_obj,sex)
    _addingHis = true
    local len = #self.handCrad.his
    self.handCrad.his[len + 1] = val
    local pos,out,lostPos

    local last = self._his[len + 1]
    if not last then 
        local tp = self.cardType << OUT        
        last = Card:create(val,tp,self.his_parent)
        self._his[len + 1] = last
    end
    last:setCardPos(self:getHisPos(len))
    local targetPos = last.transform.position
    local dest_size = MJ.getSize(last.gameObject)
    if not self.isRecord and self.cardType ~= CardType.Bottom then
        self.handCrad.card = self.handCrad.card - 1
        -- out = self._cards[#self._cards]
        out = self:getLastCard(self._cards)
       
        pos = out.transform.position
        out:remove()
        
    else
        local index = self:getCurOut(val)
        if index == 0 then 
            return 
        end
        local out = self._cards[index]
        table.remove(self.handCrad.card,index)
        self:sortCard()
        pos = out._img.transform.position
        out:remove()
        -- self:update(true)
        local size = MJ.getSize(out.gameObject)
        local s_min = math.min(size.width,size.height)
        local d_min = math.min(dest_size.width,dest_size.height)
        local s = s_min/d_min
        last.transform.localScale = Vector3(s,s,s)
    end
    
    local time = 0.15
    local his_parent = self.his_parent.transform
    local tran = last.transform
    tran:DOKill(false)
    local node_pos = self:getRectPos(last,node)
    tran.position = pos
    tran:SetParent(node.transform)
    local aniCard = Card:create(val,CardType.Ma,node)
    

    local scale = 1
    local src_size = MJ.getSize(aniCard.gameObject)
    local src_min = math.min(src_size.width,src_size.height)
    local dest_min = math.min(dest_size.width,dest_size.height)
    scale = src_min/dest_min - 0.1

    aniCard.transform:SetParent(tran)
    aniCard:setPivot(Vector2(0.5,0.5))
    MJ.setPos(aniCard.transform,0,0)
    MJ.setScale(aniCard.transform,1/scale)
    tran:DOScale(scale+0.3,time-0.1)
    if self.cardType == CardType.Left then 
        tran:DOLocalRotate(Vector3(0,0,270),time,0)
        aniCard.transform.localEulerAngles = Vector3(0,0,90)
    elseif self.cardType == CardType.Right then
        tran:DOLocalRotate(Vector3(0,0,270),time,0)    
        aniCard.transform.localEulerAngles = Vector3(0,0,90)
    end
    local tween = tran:DOMove(node_pos,time,false)
    -- Tool.SetEase(tween,DG.Tweening.Ease.OutSine)

    -- Tool.SetEase(tween,DG.Tweening.Ease.OutBounce)
    local that = self
    local delay = 0.3
    time = 0.08
    Tool.onComplete(tween,function()
        -- aniCard.transform:SetParent(tran)
        -- aniCard:setPivot(Vector2(0.5,0.5))
        -- MJ.setPos(aniCard.transform,0,0)
        -- aniCard.gameObject:SetActive(true)
        local t = tran:DOMove(targetPos,time,false)
        Tool.SetDelay(t,delay)
        t = tran:DOScale(1.0,time)
        Tool.SetDelay(t,delay)
        if that.cardType == CardType.Left or that.cardType == CardType.Right then
            t = tran:DOLocalRotate(Vector3(0,0,0),time,0)
        end
        Tool.SetDelay(t,delay)
        tran:SetParent(his_parent)
        if that.cardType == CardType.Right then
            tran:SetSiblingIndex(0)
        end
        Tool.onComplete(t,function()
            if _addingHis then
                that:update()
                that:setAniPos(card_ani_obj)
            else
                last:remove()
                that:setAniPos(card_ani_obj,-1)
                that:update()
            end
            _addingHis = false
            Object.Destroy(aniCard.gameObject)
            App.Notice(AppConst.PlaySound,"audio_card_out")

        end)
        t = aniCard.transform:DOScale(0.0,0.0)
        Tool.SetDelay(t,delay)
    end)

    App.Notice(AppConst.PlaySound,{ val,sex })
end

function CardGroup:setAniPos(ani,pos)
    pos = pos or 0
    if not self._his then return end
    local last = self._his[#self._his + pos]
    if last and last.gameObject.activeSelf then
        ani.gameObject:SetActive(true)
        local pos = last._img.transform.position
        ani.transform.position = pos
        pos = ani.transform.localPosition 
        pos.y = pos.y + 30
        ani.transform.localPosition = pos
    end
end

function CardGroup:AddCard(card)
    if (card == nil or card == -1) and self.cardType ~= CardType.Bottom then
        if type(self.handCrad.card) == "number" then 
            self.handCrad.card = self.handCrad.card + 1
        end
    elseif #self.handCrad.card < 14 then
        if self.isRecord then 
            table.insert(self.handCrad.card,card)
        elseif self.cardType == CardType.Bottom then
            table.insert(self.handCrad.card,card)
        end
    end
    self:update()
end

--碰杠
function CardGroup:CardPengGang(card,t,num)
    local heap = self.handCrad.heap
    if t == HeapType.MingGang then 
        for i = 1,#heap do 
            if heap[i].v == card then
                heap[i].t = t 
            end
        end
    else
        for i = 1,#heap do 
            if heap[i].v == card then
                return
            end
        end
        table.insert(heap,{ t = t, v = card })
    end
    if not self.isRecord and self.cardType ~= CardType.Bottom then
        local len = self.handCrad.card
        self.handCrad.card = len - num
        self._cards[#self._cards]:remove()
        for i = len - num,len do 
            local item = self._cards[i]
            if item then
                item:remove()
            end
        end
    else
        self:removeCard(card,num)
        self:sortCard()
    end
    self:update()
end

--碰
function CardGroup:CardPeng(card)
    self:CardPengGang(card,HeapType.Peng,2)
end


function CardGroup:getAnGangVal(val)
    local cards = self.handCrad.card
    local count = 1
    local dic = {}
    for i = #cards,1,-1 do 
        local v = cards[i]
        if dic[v] then 
            dic[v] = dic[v] + 1
        else
            dic[v] = 1
        end
    end
    for i,v in pairs(dic) do
        if v == 4 then 
            return i
        end
    end
    return val
end

--暗杠
function CardGroup:CardAnGang(card)
    self:CardPengGang(card,HeapType.AnGang,4)
end
--明杠
function CardGroup:CardMingGang(card)
    self:CardPengGang(card,HeapType.MingGang,1)
end
--点杠
function CardGroup:CardDianGang(card)
    self:CardPengGang(card,HeapType.DianGang,3)
end

function CardGroup:removeCard(val,num)
    local cards = self.handCrad.card
    local count = 1
    for i = #cards,1,-1 do 
        if cards[i] == val then 
            local card = self._cards[i]
            table.remove(cards,i)
            card:remove()
            if num == count then
                return
            end
            count = count + 1 
        end
    end
end

function CardGroup:getCurOut(val)
    local cards = self.handCrad.card
    for i = #cards,1,-1 do 
        if cards[i] == val then 
            local card = self._cards[i]
            if self.isRecord then return i end
            if card:isOut() then
                return i
            end
        end
    end
    for i = #cards,1,-1 do 
        if cards[i] == val then 
            return i
        end
    end
    print("not find "..val)
    
    return 0
end

function CardGroup:sortCard()
    if self.cardType ~= CardType.Bottom then return end
    local cards = self.handCrad.card
    local gui = self.gui
    table.sort(cards,function(a,b)
        if a == b then
            return false
        end
        return a < b
    end)
    
    for i = 1,#cards do 
        local c = cards[i]
        if c == gui then 
            table.remove(cards,i)
            table.insert(cards,1,c)
        end
    end
end

function CardGroup:MoveUp(card)
    for i = 1,#self._cards do 
        local item = self._cards[i]
        if item ~= card then 
            item:MoveDown()
        end
    end
end

function CardGroup:update(_bottom)
    self:_init(_bottom)
end

--点击事件
function CardGroup:setTouchEnable(ret)
    if self.isRecord then return end
    if self._cards == nil then return end
    for i = 1,#self._cards do 
        local item = self._cards[i]
        item:setTouchEnable(ret)
    end
end


function CardGroup:ShowHand(cards)
    
    self.handCrad.card = cards
    self.isRecord = true
    if self.parent then
        Tool.removeChildren(self.parent.transform)
    end
    self._cards = {}
    self._heapsAn = {}
    self._heapsMing = {}
    self:update()
    self.isRecord = false
end


function CardGroup:ResetStepStatus()
    if  self.handCrad == nil then return end
    if self._lastCards == nil then return end
    
    local cards = self.handCrad.card
    if cards == nil then return end
    
    local tt = type(cards)
    if tt == "table" then 
        self.handCrad.card = {}
        for i = 1,#self._lastCards do 
            self.handCrad.card[i] = self._lastCards[i]
        end
    else
        self.handCrad.card = self._lastLen
    end    

    local heap = self.handCrad.heap
    if heap then 
        self.handCrad.heap = {}
        for i = 1,#self._lastHeap do 
            self.handCrad.heap[i] = self._lastHeap[i]
        end
    end    

    local his = self.handCrad.his
    if his then 
        self.handCrad.his = {}
        for i = 1,#self._lastHis do 
            self.handCrad.his[i] = self._lastHis[i]
        end
    end    
    self:update()
end

function CardGroup:SaveStepStatus()
    self._lastHis = {}
    self._lastHeap = {}
    self._lastCards = {}
    self._lastLen = 0
    if  self.handCrad == nil then return end
    local cards = self.handCrad.card
    if cards == nil then return end
    
    local tt = type(cards)
    if tt == "table" then  
        for i = 1,#cards do 
            self._lastCards[i] = cards[i]
        end
    else
        self._lastLen = self.handCrad.card
    end
    local heap = self.handCrad.heap
    if heap then 
        for i = 1,#heap do 
            self._lastHeap[i] = heap[i]
        end
    end
    local his = self.handCrad.his
    if his then 
        for i = 1,#his do 
            self._lastHis[i] = his[i]
        end
    end
end

function CardGroup:HideAllHeap()
    for i = 1,#self._heapsAn do 
        self._heapsAn[i]:remove()
    end
    for i = 1,#self._heapsMing do 
        self._heapsMing[i]:remove()
    end
end

function CardGroup:HideAllHandCard()
    for i = 1,#self._cards do 
        self._cards[i]:remove()
    end
    
end


return CardGroup