---------------------------------卡-----------------------------
local Card = class("Card", BaseUI)

local DOWN = MJ.DOWN
local UP = MJ.UP
local OUT = MJ.OUT
local CardType = MJ.CardType
local Color = UnityEngine.Color

local MoveUpState = 1
local MoveDownState = 2

local CardPrefab = {}
CardPrefab[CardType.Bottom] = "bottom" --主玩家
CardPrefab[CardType.Right] = "right" --右玩家
CardPrefab[CardType.Top] = "top" --上玩家
CardPrefab[CardType.Left] = "left" --左玩家
CardPrefab[CardType.Top_Down] = "top_down" --竖，面朝下
CardPrefab[CardType.Top_Up] = "top_up" --竖，面朝上
CardPrefab[CardType.Top_OUT] = "top_up" --竖，面朝上
CardPrefab[CardType.Bottom_Down] = "down" --竖，面朝下
CardPrefab[CardType.Bottom_Up] = "up" --竖，面朝上
CardPrefab[CardType.Bottom_OUT] = "top_up" --竖，面朝上
CardPrefab[CardType.Left_Down] = "v_down" --横，面朝下
CardPrefab[CardType.Left_Up] = "left_up" --左横，面朝上
CardPrefab[CardType.Left_OUT] = "left_up" --左横，面朝上
CardPrefab[CardType.Right_Down] = "v_down" --横，面朝下
CardPrefab[CardType.Right_Up] = "right_up" --右横，面朝上
CardPrefab[CardType.Right_OUT] = "right_up" --右横，面朝上
CardPrefab[CardType.Ma] = "ma" --右横，面朝上

local card_sprite_path = "res/card/card_sprite" --图集路径

function Card:ctor(id, tp, parent)
    self.id = id
    self.cardType = tp
    self.parent = parent
    self.canOut = false
    self:_init()
end

function Card:loadSp(go,name)
    local img = go:GetComponent(UnityEngine.UI.Image)
    MJ.setSprite(img,card_sprite_path,name)
end
local _cardObj = {}

function Card:_init()
    local tp = self.cardType
    local name = CardPrefab[tp]
    if(isNull(name)) then
        -- App.Notice(AppConst.DialogShow, {
        --     msg = Localization.getText("ErrorReLogin"),
        --     type = DialogType.OneButton,
        --     onOk = function() 
        --         App.Notice(AppConst.Room_Hide)
        --         App.Notice(AppConst.ActionGetRoomInfo)
        --         -- local proxy = App.RetrieveProxy("NetworkProxy")
        --         -- proxy:Call("CleaUpPomelo")
        --         -- UnityEngine.SceneManagement.SceneManager.LoadScene(0);

        --     end
        -- })
        App.Notice(AppConst.Room_Hide)
        App.Notice(AppConst.ActionGetRoomInfo)
        error("发生错误.请重登陆")
        return
    end
    -- local prefab = Resources.Load("ui/room/card/" .. name)
    local prefab = _cardObj[name]
    if not prefab then
        prefab = Utils.ResourceMgr.Instance:LoadGameObject("ui/room/card/" .. name,false)
        prefab:SetActive(false)
        _cardObj[name] = prefab
    end
    local go = MJ.addChild(self.parent, prefab, true)
    local obj = go.gameObject
    obj:SetActive(true)
    tran = go.transform
    local size = MJ.getSize(obj)
    self.size = size
    local distance = 0
    local pivot = Vector2(0.5,0.5)
    local up = true
    local path = "img"
    if tp == CardType.Bottom then 
        path = "card_front/img"
        pivot = Vector2.zero
        distance = size.width - 4
    elseif tp == CardType.Right then
        pivot = Vector2(0.5,0)
        up = false
        distance = 27
        self:loadSp(go,'r_main')
    elseif tp == CardType.Top then
        pivot = Vector2(1,1)
        up = false
        distance = -size.width + 3
        self:loadSp(go,'t_main')
    elseif tp == CardType.Left then
        up = false
        pivot = Vector2(0.5,1)
        distance = -27
        self:loadSp(go,'l_main')
    elseif tp == CardType.Bottom_Up or tp == CardType.Bottom_OUT or tp == CardType.Ma then
        pivot = Vector2.zero
        distance = size.width - 1
    elseif tp == CardType.Bottom_Down then
        up = false
        pivot = Vector2.zero
        distance = size.width - 1
        self:loadSp(go,'b_an')
    elseif tp == CardType.Right_Up or tp == CardType.Right_OUT then
        pivot = Vector2(1,0)
        distance = size.height - 16
    elseif tp == CardType.Right_Down then
        up = false
        pivot = Vector2(1,0)
        distance = size.height - 16
        self:loadSp(go,'v_an')
    elseif tp == CardType.Top_Up or tp == CardType.Top_OUT then
        pivot = Vector2.one
        distance = -size.width + 1
    elseif tp == CardType.Top_Down then
        up = false
        pivot = Vector2.one
        distance = -size.width + 1
        local g = MJ.findChild(go,'img')
        self:loadSp(g,'b_an')
    elseif tp == CardType.Left_Up or tp == CardType.Left_OUT then
        pivot = Vector2(0,1)
        distance = -size.height + 16
    elseif tp == CardType.Left_Down then
        up = false
        pivot = Vector2(0,1)
        distance = -size.height + 16
        self:loadSp(go,'v_an')
    end
    tran.pivot = pivot
    tran.anchorMin = pivot
    tran.anchorMax = pivot
    self.transform = tran
    self.gameObject = obj
    self.distance = distance
    self.pivot = pivot
    if not up then
        return
    end
    local img = self:findType(obj, path, UnityEngine.UI.Image)
    self._img = img
    self:setTexture()
    if tp == CardType.Bottom then
        self.gui_obj = self:findChild(tran,"card_front/icon_gui").gameObject
        self:loadSp(self.gui_obj,"icon_gui")
        self.ani = self:findChild(tran,"card_front",UnityEngine.RectTransform) --obj:GetComponent(UnityEngine.Animator)
        self.event = UIDrag.Get(self.gameObject)
        self.event.onClick = Handler(self.onClick,self)
        self.event.onDragEnd = Handler(self.onDragEnd,self)
        self.event.onDragCancel = Handler(self.onDragCancel,self)
        self:setTouchEnable(false)
        self.ani_state = 0
    else
        self.gui_obj = self:findChild(tran,"icon_gui").gameObject
        self:loadSp(self.gui_obj,"icon_gui")
        self.gui_obj:SetActive(false)
    end
end

function Card:setPivot(pivot)
    local tran = self.transform
    tran.pivot = pivot
    tran.anchorMin = pivot
    tran.anchorMax = pivot
end

function Card:setTexture()
    if not self._img then return end
    local out = self.cardType & OUT
    local up = self.cardType & UP
    local tp = math.max(up,out)
    local fm = ""
    local tp = self.cardType
    if tp == CardType.Bottom then 
        fm = "b%d.png"
    elseif tp == CardType.Left_Up or tp == CardType.Left_OUT then
        fm = "l%d.png"
    elseif tp == CardType.Right_Up or tp == CardType.Right_OUT then
        fm = "r%d.png"
    elseif tp == CardType.Top_Up or tp == CardType.Bottom_Up or tp == CardType.Top_OUT or tp == CardType.Bottom_OUT or tp == CardType.Ma then
        fm = "ma%d.png"
    end
    local p = string.format(fm, self.id)
    if p == "" or p == nil then 
        -- App.Notice(AppConst.DialogShow, {
        --     msg = Localization.getText("ErrorReLogin"),
        --     type = DialogType.OneButton,
        --     onOk = function() 
        --         App.Notice(AppConst.Room_Hide)
        --         App.Notice(AppConst.ActionGetRoomInfo)
        --     end
        -- })
        -- App.Notice(AppConst.Room_Hide)
        App.Notice(AppConst.ActionGetRoomInfo)
        error("发生错误，读不到牌id.请重登陆")
        return 
    end
    MJ.setSprite(self._img, card_sprite_path, p)
end

function Card:isOut()
    return self.ani_state == MoveUpState
end

function Card:OnMoveUp()
    self.ani:DOAnchorPosY(30,0.1,false)
end

function Card:OnMoveDown()
    self.ani:DOAnchorPosY(0,0.1,false)
end

function Card:Move(ani_state)
    if not self.ani or self.ani_state == ani_state then 
        return 
    end
    -- self.ani:SetInteger("state",ani_state)
    if ani_state == MoveUpState then
        self:OnMoveUp()
    elseif ani_state == MoveDownState then 
        self:OnMoveDown()
    end
    self.ani_state = ani_state
end

function Card:MoveDown()
    if self.ani_state == MoveUpState then 
        self:Move(MoveDownState)
        App.Notice(AppConst.SelectHisCard,{val = self.id,select = false})
    end
end

function Card:onDragEnd()
    if not self.canOut then return end
    local msg = {}
    msg.op = MJ.OperationResult.Play
    msg.val = self.id
    self.ani_state = MoveUpState
    App.Notice(AppConst.ActionOperation,{msg,function() 
    end}) -- 出牌
    App.Notice(AppConst.SelectHisCard,{val = self.id,select = false})
    
end

function Card:onDragCancel()
    self.ani_state = 0
end

function Card:onClick()
    App.Notice(AppConst.PlaySound,"audio_card_click")

    if self.ani_state == 0 or self.ani_state == MoveDownState then
        self:Move(MoveUpState)
        App.Notice(AppConst.CardMoveUp,self)
        App.Notice(AppConst.SelectHisCard,{val = self.id,select = true})
    elseif self.ani_state == MoveUpState and self.canOut then
        local msg = {}
        msg.op = MJ.OperationResult.Play
        msg.val = self.id
        App.Notice(AppConst.ActionOperation,{msg,function() 
        end}) -- 出牌
        App.Notice(AppConst.SelectHisCard,{val = self.id,select = false})
        
    end
end

function Card:setSelected(ret)
    local _img = self._img
    if _img then 
        local g = 1
        if ret then 
            g = 70/255
        end
        local c = Color(g,g,g,1)
        _img.color = c
    end
end

function Card:setTouchEnable(ret)
    if self.event then 
        -- self.event.enabled = ret
        self.canOut = ret
        self.event.canMove = ret
    end
end

--获取距离
function Card:getDistance()
    return self.distance
end

function Card:isGui(gui)
    if self.gui_obj then
        local ret = self.id == gui
        self.gui_obj.gameObject:SetActive(ret)
    end
end

function Card:setCardPos(pos,level)
    level = level or 0
    local d = (self.cardType >> DOWN)
    if d > 4 then d = 0 end
    local u = (self.cardType >> UP)
    if u > 4 then u = 0 end
    local o = self.cardType >> OUT
    if o > 4 then o = 0 end
    local tp = math.max(d,u)
    tp = math.max(tp,o)
    if tp == 0 then
        tp = self.cardType
    end
    local dir = 1
    
    if tp == CardType.Left or tp == CardType.Right then
        if tp == CardType.Right then
            dir = -1
        end
        MJ.setPos(self.gameObject,level * self.size.width * dir,pos)        
    elseif self.cardType == CardType.Top_Down then
        MJ.setPos(self.gameObject,pos,2)
    else
        local h = self.size.height
        if tp == CardType.Top then
            dir = -1
            h = h - 13
        end
        MJ.setPos(self.gameObject,pos,level * (h) * dir)
    end
    if tp == CardType.Right then 
        self.transform:SetSiblingIndex(0)
    end
end

function Card:setHeapCardPos(pos,down)
    pos = pos - self.distance*2
    local fix = 0
    local out = self.cardType >> OUT
    if out > 4 then out = 0 end
    local up = self.cardType >> UP
    if up > 4 then up = 0 end
    local tp = math.max(up,out)
    if tp == CardType.Right then 
        if down then 
            fix = -8
        else 
            fix = 2
        end
        pos = pos + self.distance / 2 - fix
        MJ.setPos(self.gameObject,0,pos)        
    elseif tp == CardType.Left then
        if down then 
            fix = 7
        else 
            fix = 2
        end
        pos = pos - self.distance / 2 - fix
        MJ.setPos(self.gameObject,0,pos)
    elseif tp == CardType.Top then
        MJ.setPos(self.gameObject,pos + fix,15)
    elseif tp == CardType.Bottom then
        MJ.setPos(self.gameObject,pos + fix,15)
    end
end

function Card:getPos()
    return MJ.getPos(self.gameObject)
end

function Card:remove()
    -- Object.Destroy(self.gameObject)
    if self.ani then 
        if self.ani_state == MoveUpState then 
            App.Notice(AppConst.SelectHisCard,{val = self.id,select = false})
        end
        self.ani_state = 0
        self.ani:DOKill(false)
        -- self.ani:SetInteger("state",self.ani_state)
        self:OnMoveDown()
    end
    MJ.setPos(self.gameObject,10000,10000)
    self.isRemove = true
    -- self.gameObject:SetActive(false)
    self:setSelected(false)
end


function Card:update(val,type)
    self:setPivot(self.pivot)
    if self.ani_state == MoveUpState then 
        App.Notice(AppConst.SelectHisCard,{val = self.id,select = false})
    end
    self.ani_state = 0
    -- self.gameObject:SetActive(true)
    if self.ani then
        -- self.ani:Rebind()
        self:OnMoveDown()
        -- self.ani:SetInteger("state",self.ani_state)
    end
    self.id = val
    self.cardType = type
    self:setTexture()
    self.isRemove = false
end

return Card
