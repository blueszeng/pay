---------------------------------主页-----------------------------
local UIHome = class("UIHome", BaseUI)
local Tool = Utils.Tool
local TableReader = Data.TableReader.Instance
local PlayerPrefs = UnityEngine.PlayerPrefs
local UpdateMsgMgr = require "setting.UpdateMsgMgr"

local NOTICE_SHOW_TIME = 15


function UIHome:ctor()
    self:load("ui/home/ui_home", UIType.Normal, UIMode.HideOther, UICollider.Normal)
end

function UIHome:Awake()
    -- self:setNickName("")
    -- self:setFangKa("0")
    -- self:setID("")
    -- self:setHead("")
    --App.Notice(AppConst.GetUserInfo)
    if MJ.ForIosAudit then
        self.notice:SetActive(false)
        self.btnShare.gameObject:SetActive(false)
        self.btnBuyFangKa.gameObject:SetActive(false)
        self.fangka_node:SetActive(false)
        self.btnProblem.gameObject:SetActive(false)
        self.btnGuide.gameObject:SetActive(false)
    end
    self.messages = {}--跑马灯消息列表
    local localMessages = {}
    TableReader:ForEachTable("msg", function(index, item)
        table.insert(localMessages, item:Get("msg"))
        return false
    end)
    self.localMessages = localMessages
    self.isRolling = false
end

-- function UIHome:Hide()
--     self:close()
-- end

function UIHome:Refresh()
    self:setUserInfo(MJ.player)
    App.Notice(AppConst.PlayMusic, SoundName.Music)
    
    self:CompleteRollMsg()
    
    self:ShowMsg()
    if MJ.OnMessageCache then 
        self:OnMessage(MJ.OnMessageCache)
        MJ.OnMessageCache = nil
    end
end

function UIHome:ShowMsg()
    if MJ.ForIosAudit then return end
    if MJ.updateSuccess then
        MJ.updateSuccess = false
        local msg = {
            private = UpdateMsgMgr.getNew() or ""
        }
        if not isNull(msg.private) then 
            App.Notice(AppConst.MsgShow,msg)
            return
        end
    end
    local red_point = self.red_point
    local old = PlayerPrefs.GetInt("MsgDate", 0)
    local day = os.date("*t").day
    if day ~= old then
        App.Notice(AppConst.ActionGetPublicMessage,function(msg)
            if isNull(msg.public) and isNull(msg.private) then
                return
            end
            PlayerPrefs.SetInt("MsgDate", day)
            App.Notice(AppConst.MsgShow,msg)
            red_point:SetActive(false)
        end)
    end
end

function UIHome:OnMessage(msg)
    self:runNotice(msg.msg, msg.level)
end

--msg 消息,
--num 需要滚动几次
function UIHome:runNotice(msg, num)
    if isNull(msg) then return end
    if self.isRolling then
        if num >= 5 then
            table.insert(self.localMessages, msg)
        elseif num > 1 then
            for i = 2, num do
                table.insert(self.messages, msg)
            end
        else
            table.insert(self.messages, msg)
        end
        return
    end
    if num >= 5 then
        table.insert(self.localMessages, msg)
    elseif num > 1 then
        for i = 2, num do
            table.insert(self.messages, msg)
        end
    end
    self.isRolling = true
    local tran = self.txt_notice:GetComponent(RectTransform)
    local size = MJ.getSize(tran.parent)
    MJ.setPosX(tran, size.width)
    self.txt_notice.text = msg
    local width = self.txt_notice.preferredWidth
    tran:DOKill(false)
    local tween = tran:DOAnchorPosX(-width, NOTICE_SHOW_TIME, false)
    Tool.SetEase(tween, DG.Tweening.Ease.Linear)
    local that = self
    Tool.onComplete(tween, function()
        that:CompleteRollMsg()
    end)
end

function UIHome:CompleteRollMsg()
    self.isRolling = false
    
    if #self.messages > 0 then
        local msg = table.remove(self.messages, 1)
        self:runNotice(msg, 1)
    else
        local index = 1
        local len = #self.localMessages
        if len > 1 then
            index = math.random(1, len)
        end
        self:runNotice(self.localMessages[index], 1)
    end
end

function UIHome:onClick(go, name)
    if name == "btnBuyFangKa" then
        self:onBuyFangeKa()
    elseif name == "btnRecord" then
        self:onRecord()
    elseif name == "btnMsg" then
        self:onMsg()
    elseif name == "btnGuide" then
        self:onGuide()
    elseif name == "btnShare" then
        self:onShare()
    elseif name == "btnSetting" then
        self:onSetting()
    elseif name == "btnCreate" then
        self:onCreate()
    elseif name == "btnAdd" then
        self:onAdd()
    elseif name == "btnHead" then
        self:onShowTips()
    elseif name == "btnReturnRoom" then
        self:onReturnRoom()
    elseif name == "btnProblem" then
        App.Notice(AppConst.FeedbackShow)
    end
end



function UIHome:setUserInfo(player)
    if player == nil then return end
    
    if player == nil then
        --读取缓存
        self:setNickName("")
        self:setFangKa("0")
        self:setID("")
        self:setHead("")
    else
        self:setNickName(player.nickname)
        self:setHead(player.headimgurl)
        self:setFangKa(string.format("%d",player.cardNum))
        self:setID(player.id)
        local ret = player.room > 0
        self.btnReturnRoom.gameObject:SetActive(ret)
        self.btnCreate.gameObject:SetActive(not ret)
    end
end

--{"cardNum":8} 自己钻石数量发生变化更新
function UIHome:OnCardUpdate(msg)
    MJ.player.cardNum = msg.cardNum
    self:setFangKa(string.format("%d",MJ.player.cardNum))
end

function UIHome:setNickName(name)
    self.lab_name.text = name
end

function UIHome:setHead(img)
    if isNull(img) then
        self.img_head.gameObject:SetActive(false)
    else
        self.img_head.gameObject:SetActive(true)
        MJ.SetNetImage(self.img_head,img)
        -- self.img_head.Url = img
        -- self.img_head:SaveImage(FileUtils.getInstance():getWritablePath() .. "playerHead.png")
    end
end

function UIHome:setFangKa(fk)
    self.lab_fangka.text = fk
end

function UIHome:setID(id)
    self.lab_id.text = "ID:" .. id
end

-----------------------------------事件---------------------------------------
function UIHome:onBuyFangeKa()
    App.Notice(AppConst.DialogShow, {msg = Localization.getText("BuyFangKaTips"), type = DialogType.NoButton, title = DialogTitle.Tips})
end

function UIHome:onRecord()
    App.Notice(AppConst.RecordShow)
end

function UIHome:onMsg()
    App.Notice(AppConst.MsgShow)
    self.red_point:SetActive(false)
end

function UIHome:onGuide()
    App.Notice(AppConst.GuideShow)
end

function UIHome:onShare()
    App.Notice(AppConst.ShareShow)
end

function UIHome:onSetting()
    App.Notice(AppConst.SettingShow, 1)
end

function UIHome:onCreate()
    App.Notice(AppConst.Room_Create_Show)
end

function UIHome:onReturnRoom()
    App.Notice(AppConst.ActionGetRoomInfo)
end

function UIHome:isInRoom()
    return MJ.player.room ~= 0
end

function UIHome:onAdd()
    if self:isInRoom() then
        App.Notice(AppConst.DialogShow, Localization.getText("HasInRoom"))
    else
        App.Notice(AppConst.Room_Add_Show)
    end
end

function UIHome:onShowTips()
    if MJ.player == nil then
        return
    end
    App.Notice(AppConst.ShowPlayerInfo,MJ.player)

    
end
-----------------------------------------------------------------------------
return UIHome
