---------------------------------游戏结算-----------------------------
local UIGameResult = class("UIGameResult", BaseUI)
local Tool = Utils.Tool
local Color = UnityEngine.Color
local Card = require "model.vos.Card"
local CardType = MJ.CardType
local card_sprite_path = "res/card/card_sprite"
local TableReader = Data.TableReader.Instance
local Image = UnityEngine.UI.Image

function UIGameResult:ctor()
    self:load("ui/result/ui_result", UIType.PopUp, UIMode.DoNothing, UICollider.Normal)
end

function UIGameResult:Awake()
    self.resultLayer:SetActive(false)
    self.maLayer.gameObject:SetActive(false)
    self.endLayer.gameObject:SetActive(false)
    self.item.gameObject:SetActive(false)
    self.bg.gameObject:SetActive(false)
end

function UIGameResult:Refresh()
    local data = self.data
    local time = data.time or 0
    -- data.showMa = true
    local that = self
    if time > 0 then
        LuaTimer.Add(time,function(id) 
            that:init()
            return false
        end)
    else
    
        self:init()
    end
    
    
end

function UIGameResult:init()
    local data = self.data
    local showMa = data.showMa
    local that = self
    self.txt_guide.text = self:getGuide(data.room_data.opt) or ""
    if showMa then
        self:showMaLayer(data.result,data.room_data.users,function() 
            that.bg.gameObject:SetActive(true)
            that:setMa(data.result,data.room_data.users)
            that:loadCards(data.result,data.room_data,data.info)
        end)
    else
        that.bg.gameObject:SetActive(true)
        that:setMa(data.result,data.room_data.users)
        that:loadCards(data.result,data.room_data,data.info)
    end
    self._inited = true
    self:updateState()
end

function UIGameResult:updateState()
    local state = App.RetrieveMediator("GameResultMediator"):Call("getRoomState")
    self.ready:SetActive(state ~= true)
    self.ok:SetActive(false)
    if state then 
        local final = self.data.result.final
        if final and final ~= cjson.null then
            self.ready:SetActive(false)
            self.endgame:SetActive(true)
            self.ok:SetActive(false)
        else
            self.ready:SetActive(false)
            self.endgame:SetActive(false)
            self.ok:SetActive(true)
        end
    else
        self.endgame:SetActive(false)
    end
    
    if self.data.isRecord then 
        self.ready:SetActive(false)
        self.endgame:SetActive(false)
        self.ok:SetActive(true)    
    end
end

function UIGameResult:removeCards(cards, val,num)
    local count = 1
    for i = #cards,1,-1 do 
        if cards[i] == val then 
            table.remove(cards,i)
            if num == count then
                return
            end
            count = count + 1
        end
    end
end

function UIGameResult:getHufa(hufa_num)    
  
    local msg = ""
    local value = 0
    
    local row = TableReader:ForEachTable("hufa",function(index,row)
        value = row:Get("value")
        if hufa_num & value == value then 
            local name = row:Get("name")
            msg = msg .. name
            msg = msg .. " "
        end
        return false
    end)
    
    return msg
end

function UIGameResult:getGang(heap)
    local msg = ""
    local v,t
    local arg = {0,0,0,0}
    for i = 1,#heap do 
        local item = heap[i]
        t = item.t
        arg[t+1] = arg[t+1] + 1
    end
    local ming_gang = arg[MJ.HeapType.MingGang + 1]
    local an_gang = arg[MJ.HeapType.AnGang + 1]
    local dian_gang = arg[MJ.HeapType.DianGang + 1]
    if ming_gang > 0 then 
        msg = msg .. Localization.getText("HeapTypeMingGang",ming_gang) .. " "
    end
    if an_gang > 0 then 
        msg = msg .. Localization.getText("HeapTypeAnGang",an_gang) .. " "
    end
    if dian_gang > 0 then 
        msg = msg .. Localization.getText("HeapTypeDianGang",dian_gang) .. " "
    end
    return msg
end

--加载手牌
function UIGameResult:loadCards(msg,room_data,info)
    local gui = MJ.GUI
    local cards = msg.cards
    if not info then return end
    local players = info.players
    local hu_list = msg.hu or {}
    local gen = self.data.result.score.gen
    
    if hu_list == cjson.null then
        hu_list = {}
    end
    local opt = room_data.opt
    local users = room_data.users
    local grid = self.grid
    if gui == -1 then 
        self.txt_gui:SetActive(false)
    else
        self.txt_gui:SetActive(true)
        local card_obj = Card:create(gui,CardType.Bottom_Up,self.gui_node)
        card_obj:isGui(gui)
    end
    
    local score = msg.score.round
    for i = 1,#cards do 
        local card = cards[i]
        local user = users[i]
        
        local item = MJ.addChild(grid,self.item,true)
        local item_obj = {}
        item:Init(item_obj)
        --名字
        item_obj.txt_name.text = user.info.name

        --胡
        local isHu = false
        local hu = hu_list[(i-1)..""]
        local player = players[i]
        local heap = player.heap

        --庄家
        local gen_msg = ""
        local isHost = MJ.HOST == i-1
        item_obj.icon_host:SetActive(isHost)
        if isHost and gen == 1 then 
            gen_msg = Localization.getText("GenZhuang")
        end

        if hu and hu ~= cjson.null then 
            isHu = true
            --牌组
            item_obj.txt_reward.text = self:getHufa(hu.way) .. self:getGang(heap) .. " " .. gen_msg
        else
            item_obj.txt_reward.text = self:getGang(heap) .. " " .. gen_msg
        end
        item_obj.hu:SetActive(isHu)

        
        --输分
        local num = score[i]
        if num == cjson.null then
            num = 0
            score[i] = 0
        end
        item_obj.txt_score.text = string.format("%d",num)

        

        local pos = 0
        local parent = item_obj.card_node
        
        local _card_obj,val,t,j
        for k = 1,#heap do
            val = heap[k].v
            t = heap[k].t
            j = 4
            local _remove = 3
            if t == MJ.HeapType.Peng then 
                j = 3
                _remove = 1
            elseif t == MJ.HeapType.AnGang then
                j = 4
                _remove = 4
            end
            self:removeCards(card,val, _remove)
            for h = j,1,-1 do 
                if t == MJ.HeapType.AnGang and h > 1 then
                    _card_obj = Card:create(val,CardType.Bottom_Down,parent)
                else
                    _card_obj = Card:create(val,CardType.Bottom_Up,parent)
                    _card_obj:isGui(gui)
                end
                _card_obj:setCardPos(pos)
                pos = pos + _card_obj:getDistance()            
            end
            pos = pos + 5
        end
        for k = 1,#card do
            val = card[k]
            _card_obj = Card:create(val,CardType.Bottom_Up,parent)
            _card_obj:setCardPos(pos)
            _card_obj:isGui(gui)
            pos = pos + _card_obj:getDistance()
        end
    end
end

function UIGameResult:setMa(msg,users)
    self.resultLayer:SetActive(true)
    local grid = self.ma_grid
    local ma = msg.ma
    local hu = msg.hu
    local list = {}
    if not ma or ma == cjson.null or #ma == 0 then
        self.txt_ma:SetActive(false)
        -- self.img_title_liuju.gameObject:SetActive(true)
        -- App.Notice(AppConst.PlaySound,"audio_liuju")
    else
        for i = 1,#ma do 
            local id = ma[i]
            local obj = Card:create(id,CardType.Bottom_Up,grid)
            obj.gameObject:SetActive(true)
            local _img = obj._img
            local g = 70/255
            local c = Color(g,g,g,1)
            _img.color = c
            local it = { img = _img }
            list[i] = it
        end
    end

    if not hu or hu == cjson.null then 
        self.txt_ma:SetActive(false)
        self.img_title_liuju.gameObject:SetActive(true)
        App.Notice(AppConst.PlaySound,"audio_liuju")
        return
    end

    local me
    local other

    local score = msg.score.round
    for i = 1,#score do 
        local user = users[i]
        if user.uid == MJ.player.id then 
            me = score[i]
            if me == cjson.null then me = 0 end
        end
    end
    if me and me > 0 then
        App.Notice(AppConst.PlaySound,"audio_win")
        self.img_title_win:SetActive(true)
    else
        App.Notice(AppConst.PlaySound,"audio_lose")
        self.img_title_lose:SetActive(true)
    end

    me = nil
    for i,v in pairs(hu) do
        if v and v ~= cjson.null then
            local idx = tonumber(i) + 1
            local user = users[idx]
            if user.uid == MJ.player.id then 
                me = v
            end
            other = v       
        end
    end

    local _hu = me or other
    for i = 1,#_hu.zhong do 
        local idx = _hu.zhong[i] + 1
        local it = list[idx]
        it.img.color = Color.white
    end

end

function UIGameResult:getGuide(opt)
    local id = opt.type
    local gui = opt.gui
    local ma = opt.ma
    local wanfa_num = opt.wanfa
    local hufa_num = opt.hufa
  
    local msg = ""
    
    local row = TableReader:TableRowByID("mj_type",id)
    local wanfa = row:getItem("wanfa")
    local wanfa_len =  wanfa.Count - 1
    
    local value = 0
    for i = 0,wanfa_len do
        local name = wanfa:Get(i)
        local item = TableReader:TableRowByUnique("wanfa","name",name)
        if not item:IsNull() then
            value = item:Get("value")
            if wanfa_num & value == value then 
                msg = msg .. name
                msg = msg .. " "
            end
        else
            item = TableReader:TableRowByUnique("hufa","name",name)
            if not item:IsNull() then
                value = item:Get("value")
                if hufa_num & value == value then 
                    msg = msg .. name
                    msg = msg .. " "
                end
            end
        end
    end
    return msg
end


--显示买马
function UIGameResult:showMaLayer(msg,users,cb)
    local grid = self.m_grid
    local ma = msg.ma
    local hu = msg.hu
    local list = {}
    if not ma or ma == cjson.null or #ma == 0 then
        if cb then cb() end
        return
    end
    self.maLayer:SetActive(true)
    local ma_len = #ma
    if ma_len == 4 then 
        MJ.setSize(grid,Vector2(400,466))
    elseif ma_len == 8 then
        MJ.setSize(grid,Vector2(800,466))
    elseif ma_len == 10 then
        MJ.setSize(grid,Vector2(1000,466))
    elseif ma_len > 10 then
        MJ.setSize(grid,Vector2(1334,750))
    else
        MJ.setSize(grid,Vector2(600,466))
    end
    local fan_list = {}
    for i = 1,#ma do 
        local id = ma[i]
        local obj = Card:create(id,CardType.Ma,grid)
        local go = GameObject("FanGui")
        local img = go:AddComponent(Image)
        
        MJ.setSprite(img,"res/card/card_sprite","fan.png",true)
        MJ.addChild(obj,img)
        MJ.setPos(go,0,0)
        MJ.setScale(go,1.2)
        obj.gameObject:SetActive(true)
        local _img = obj._img
        local g = 70/255
        local c = Color(g,g,g,1)
        _img.color = c
        local it = { img = _img }
        list[i] = it
        fan_list[i] = go
    end

    local me
    local other
    for i,v in pairs(hu) do
        if v ~= cjson.null then
            local idx = tonumber(i) + 1
            local user = users[idx]
            if user.uid == MJ.player.id then 
                me = v
            end
            other = v
        end
    end

    local _hu = me or other
    for i = 1,#_hu.zhong do 
        local idx = _hu.zhong[i] + 1
        local it = list[idx]
        it.img.color = UnityEngine.Color.white
    end

    local maLayer = self.maLayer
    maLayer:SetActive(true)
    local len = #ma
    local index = 1
    LuaTimer.Add(1000,200,function(id)
        if len < index - 5 then 
            if not Slua.IsNull(maLayer) then
                maLayer:SetActive(false)
                if cb then cb() end
            end
            return false
        end
        if fan_list[index] and not Slua.IsNull(fan_list[index]) then
            fan_list[index]:SetActive(false)
        end
        index = index + 1
        return true
    end)
    list = nil
end

function UIGameResult:Hide()
    self:close()
    self._inited = false
end




function UIGameResult:showEnd()
    local final = self.data.result.final
    local users = self.data.room_data.users
    self.resultLayer:SetActive(false)
    self.endLayer:SetActive(true)
    self.item_end.gameObject:SetActive(false)
    local grid = self.grid_end
    local max = 0
    local score = self.data.result.score.final
    local maxIndex = 0
    for i = 1,#score do 
        local num = score[i]
        if num == cjson.null then
            score[i] = 0
            num = 0
        end
        if num > max then 
            max = num 
            maxIndex = i
        end
    end

    
    for i = 1,#users do 
        local user = users[i]
        local item = MJ.addChild(grid,self.item_end,true)
         local item_obj = {}
        item:Init(item_obj)
        --名字
        item_obj.txt_name.text = user.info.name
        item_obj.txt_id.text = string.format("ID:%d",user.info.uid)
        item_obj.icon_room:SetActive(i == 1)
        item_obj.txt_score.text = string.format("%d",score[i]-5000)
        item_obj.winner:SetActive(i == maxIndex)
        local list = final[i]
        item_obj.txt_his.text = Localization.getText("GameResult",list[1],list[2],list[3],list[4],list[5])
        if user.info.head then
            item_obj.img_head.Url = string.gsub(user.info.head,"/0","/132")
        end
    end
end

function UIGameResult:onClick(go,name)
    if name == "btn_ready" then
        if self.data.isRecord then 
            App.Notice(AppConst.GameResult_Hide)
            App.Notice(AppConst.RecordPlayHide)
            return
        end
        local state = App.RetrieveMediator("GameResultMediator"):Call("getRoomState")
        if state then
            local final = self.data.result.final
            if final and final ~= cjson.null then
                self:showEnd()
            else
                App.Notice(AppConst.GameResult_Hide)
                App.Notice(AppConst.Room_Hide)
            end
            return
        end
        App.Notice(AppConst.ActionReady)
    elseif name == "btn_back" then
        App.Notice(AppConst.GameResult_Hide)
        App.Notice(AppConst.Room_Hide)
    elseif name == "btn_share" then
        App.Notice(AppConst.ShareCaptureScreenshot)
    end
end



return UIGameResult