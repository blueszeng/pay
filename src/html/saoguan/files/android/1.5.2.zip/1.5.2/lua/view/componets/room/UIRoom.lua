---------------------------------游戏界面-----------------------------
local UIRoom = class("UIRoom", BaseUI)
local PlayerHead = require "view.componets.room.PlayerHead"
local Tool = Utils.Tool
local PlayerInfo = require "model.vos.PlayerInfo"
local CardGroup = require "view.componets.room.CardGroup"
local Card = require "model.vos.Card"
local Image = UnityEngine.UI.Image
local PlayDSound = false
local TableReader = Data.TableReader.Instance
function UIRoom:ctor()
    self:load("ui/room/ui_room", UIType.Normal, UIMode.HideOther, UICollider.Normal)
end



function UIRoom:getGuide(opt)
    local id = opt.type
    local gui = opt.gui
    local ma = opt.ma
    local wanfa_num = opt.wanfa
    local hufa_num = opt.hufa
    local cost = opt.cost
    local cost_num = 8
    if cost == 2 then 
        cost_num = 16
    elseif cost == 3 then 
        cost_num = 24
    end
    local msg = ""
    msg = msg .. Localization.getText("Cost",cost_num)
    if ma > 0 then
        msg = msg .. " "
        msg = msg .. Localization.getText("Ma",ma)
    end
    if gui == 1 then 
        msg = msg .. " "    
        msg = msg .. Localization.getText("Gui",ma)
    elseif gui == 2 then
        msg = msg .. " "    
        msg = msg .. Localization.getText("FanGui",ma)
    end
    local row = TableReader:TableRowByID("mj_type",id)
    local wanfa = row:getItem("wanfa")
    local wanfa_len =  wanfa.Count - 1
    
    local value = 0
    for i = 0,wanfa_len do
        local name = wanfa:Get(i)
        local item = TableReader:TableRowByUnique("wanfa","name",name)
        if not item:IsNull() then
            value = item:Get("value")
            if wanfa_num & value == value then 
                msg = msg .. " "
                msg = msg .. name
            end
        else
            item = TableReader:TableRowByUnique("hufa","name",name)
            if not item:IsNull() then
                value = item:Get("value")
                if hufa_num & value == value then 
                    msg = msg .. " "
                    msg = msg .. name
                end
            end
        end
    end
    return row:Get("name"),msg
end

--规划
function UIRoom:getRule()
    return self.data.opt
end

function UIRoom:Awake()
    self.playList = {}
    self.PlayerHeadList = {}
    self._IdxList = {}
    self.groups = {}
    self.arow_ani.gameObject:SetActive(false)
    self.card_ani_obj.gameObject:SetActive(false)
    self.gui_obj:SetActive(false)
    self.btnRule.gameObject:SetActive(false)
    self.game_state:SetActive(false)
    self._full = 1
    self.player_head.gameObject:SetActive(false)
    for i = 1,4 do 
        local m_head = self:loadHead(self["player_node" .. i])
        self.PlayerHeadList[i] = m_head
        m_head:hide()
    end
end

function UIRoom:Refresh()
    self.isRecord = false
    self._start = false
    self._inited = true
    -- self:NewGame()
   
    self.roomNumber = math.ceil(self.data.id)
    local name,msg = self:getGuide(self.data.opt)
    local data = {
        title = Localization.getText("ShareInvite", name, self.roomNumber),
        desc = msg,
        arg = "path=joinRoom&id="..self.roomNumber
    }
    App.Notice(AppConst.Room_Menu_Show, data)
    App.Notice(AppConst.Room_Invite_Hide)
    self.lab_room_num.text = self.roomNumber
    local that = self
    that:loadData()
    LuaTimer.Add(100,function(id) 
        App.Notice(AppConst.YayaLogin,that.roomNumber)--登陆语音
        return false
    end)
end

function UIRoom:HideStatus()
    for i = 1,4 do 
        self["state" .. i]:SetActive(false)
    end
end

function UIRoom:UpdatePlayerStatus()
    local playerList = self.playerList
    for i = 1, #playerList do
        local user = playerList[i]
        local m_head = self.PlayerHeadList[i]
        if user and user ~= 0 and user ~= cjson.null then            
            local ret = user.ready == 1
            self["state" .. i]:SetActive(ret)            
        end
    end
end
function UIRoom:loadData()
    local all_ready,full = self:loadUsers()
    local that = self
   
    if all_ready == 4 then
        self:HideStatus()
        local closer = self.data.closer
        if closer and closer ~= cjson.null then 
            local agree = 0
            local disAgree = 0
            local frist = 0
            for i,v in pairs(closer) do 
                if v == 1 then 
                    disAgree = disAgree + 1
                elseif v == 2 then
                    agree = agree + 1
                elseif v == 3 then
                    frist = 1
                end
            end
            
            
            if frist >= 1 and disAgree <= 1 then 
                self:OnChoose(closer)
            end
        end
        if self._startData then
            ---有开始数据，不再请求
            that:StartGame(self._startData)
            self._startData = nil
        else
            App.Notice(AppConst.ActionGetGameInfo,function(msg)
                that:StartGame(msg)
            end)
        end

        
    else
        if full and self.playerList[1].ready == 0 then 
            App.Notice(AppConst.ActionGetGameInfo,function(msg)
                that:StartGame(msg)
                App.Notice(AppConst.ActionGetGameUpdate,function(result) 
                    local data = result.result
                    if data ~= cjson.null and data.hu then 
                        App.Notice(AppConst.GameResult_Show,{room_data = that.data,result = data,info = msg, showMa = false,time = 0})
                    end
                end)
            end)
        end
        if not full then
            self.state1:SetActive(true)        
        end
        
    end
    self.btnRule.gameObject:SetActive(true)
    
end

function UIRoom:loadHead(parent, data)
    local head = Object.Instantiate(self.player_head)
    local player = PlayerHead:create()
    head:Init(player)
    MJ.addChild(parent, head)
    player:addClick()  
    if data then 
        player:update(data)
    end
    return player
end

function UIRoom:getUser(idx)
    local users = self.data.users
    idx = string.format("%d",idx)
    local user = users[idx]
    if not user then user = users[idx + 1] end
    if user == cjson.null then return nil end
    return user    
end

---玩家加入房间
function UIRoom:loadUsers()
    self:HideStatus()
    local users = self.data.users
    local playerList = {}
    local me_id = MJ.player.id
    local find_index = 0
    local index = 1
    for i = 1, 4 do
        local user = self:getUser(i-1)
        if user then 
            local uid = user.uid
            if find_index == 0 and uid == me_id then
                find_index = i
                index = 1
                playerList[index] = user            
            end
            if i == 1 then 
                App.Notice(AppConst.Room_Menu_UpdateState,uid == me_id)
            end
        end
        if find_index < i then
            index = index + 1
            playerList[index] = user or 0
        end
    end
    for i = 1,find_index - 1 do
        local user = self:getUser(i-1)
        index = index + 1
        
        playerList[index] = user or 0
    end
    
    local full = true
    local all_ready = 0
    
    for i = 1, #playerList do
        local user = playerList[i]
        local m_head = self.PlayerHeadList[i]
        if user and user ~= 0 and user ~= cjson.null then
            local player = PlayerInfo:create(user.info)
            m_head:update(player)
            m_head:udpateNet(user.ol or 1)
            local ret = user.ready == 1
            self["state" .. i]:SetActive(ret)
            all_ready = all_ready + user.ready
            self._IdxList[user.idx + 1] = i
        else
            if m_head then 
                m_head:hide()
            end
            full = false
        end
    end
    self.playerList = playerList
    if not full then
        App.Notice(AppConst.Room_Invite_Show)
    else
        self._start = true
    end
    self._full = full
    return all_ready,full
end

function UIRoom:isFull()
    return self._full
end

function UIRoom:getPosAndImgByUid(uid)
    local playerList = self.playerList
    for i = 1,#playerList do 
        local user = playerList[i]
        if user and user ~= 0 and user ~= cjson.null then
            local info = self.PlayerHeadList[i]
            if info then
                local id = string.format("%d",user.uid)
                if id == tostring(uid) then return i,info.data.headimgurl,info.data.sex end
            end
        end
    end
    return 0,"",0
    -- return 1,"playerHead.png",1
end


function UIRoom:Hide()
    
    self:clearTimer()
    
    if self.playTimer then
        LuaTimer.Delete(self.playTimer)
    
    end
    App.Notice(AppConst.Room_Menu_Hide)
    -- self:close()
    self:NewGame()
    
    self.gameObject:SetActive(false)
    self._inited = false
    self.showResult = false
    -- Utils.SpriteManager.Instance:remove("res/card/card_sprite")
    App.Notice(AppConst.YayaLogout,self.roomNumber)
    self.groups = {}
    -- self.PlayerHeadList = {}
    self.playerList = {}
    self._IdxList = {}
    self._start = false
    self._startData = nil
end


function UIRoom:setArow(tp)
    tp = tp or 0
    self.arow_ani.gameObject:SetActive(true)
    if tp >= 1 and tp <= 4 then
        self.arow_ani:SetInteger("type",tp)
        self:startTimer(tp == 1)
    end
    
end



function UIRoom:MoveUp(card)
    self.groups[card.cardType]:MoveUp(card)
end

function UIRoom:GetIdx(idx)
    if self._IdxList == nil then return 1 end
    return self._IdxList[idx+1]
end

function UIRoom:getCardsNum(hand_card)
    local card = hand_card.card
    local num = 0
    if type(card) == "table" then
        num = num + #card
    else
        num = num + card
    end
    local heap = hand_card.heap
    for i = 1,#heap do 
        num = num + 3
    end
    return num
end

function UIRoom:NewGame()
    if not self.groups then return end
    self.arow_ani.gameObject:SetActive(false)
    self.card_ani_obj.gameObject:SetActive(false)
    for i = 1,#self.groups do 
        self.groups[i]:clear()
    end
end

function UIRoom:showFanGui(gui)
    if self.gui_obj.transform.childCount == 0 then return end
    local go = GameObject("FanGui")
    local img = go:AddComponent(Image)
    MJ.setSprite(img,"res/card/card_sprite","fan.png",true)
    MJ.addChild(self.arow_ani,img)
    local tran = go.transform
    local node_pos = self.gui_node.transform.position
    local p_size = MJ.getSize(self.arow_ani)
    local gui_obj = self.gui_obj.transform:GetChild(0).gameObject
    gui_obj:SetActive(false)
    local time = 1.0
    LuaTimer.Add(1000,function(id)
        MJ.setSprite(img,"res/card/card_sprite",string.format("ma%d.png",gui),true)
        LuaTimer.Add(1000,function(id)
            local size = MJ.getSize(tran)
            MJ.setPivot(tran,Vector2(0,0))
            MJ.setPos(tran,p_size.width/2 - size.width/2,p_size.height/2 - size.height/2)
            local tween = tran:DOMove(node_pos,time,false)
            tran:DOScale(0.6,time)
            Tool.onComplete(tween,function()
                gui_obj:SetActive(true)
                GameObject.Destroy(go)
            end)
        end)
    end)
end

----------------------------------------消息通知----------------------------------------------------
function UIRoom:StartGame(msg,frist)
    self._lastHisIdx = nil -- 记录最后一个出牌。
    self.cur_card_ani:DOPause()
    self.card_ani_obj.gameObject:SetActive(false)
    App.Notice(AppConst.Room_Invite_Hide)
    self.arow_ani.gameObject:SetActive(true)
    self:startTimer(false)
    for i = 1,4 do 
        self["state" .. i]:SetActive(false)
    end
    self.info = msg
    local host = msg.host
    local gui = msg.gui
    MJ.GUI = gui
    
    if gui == -1 then 
        self.gui_obj:SetActive(false)
    else
        self.gui_obj:SetActive(true)
        Tool.removeChildren(self.gui_node.transform)
        local gui_card = Card:create(gui,MJ.CardType.Bottom_Up,self.gui_node)
        gui_card:isGui(gui)
    end
    MJ.HOST = host
    local room_idx = self:GetIdx(host)
    for i = 1,#self.PlayerHeadList do 
        local head = self.PlayerHeadList[i]
        head:isHost(room_idx == i)
        head:showJian(false)
    end
    local jian = msg.jian or {}
    for i,v in pairs(jian) do 
        if v ~= cjson.null then
            local idx = self:GetIdx(i)
            local head = self.PlayerHeadList[idx]
            local target = self.PlayerHeadList[self:GetIdx(v)]
            head:showJian(true,target.data.headimgurl)
        end
    end
    local players = msg.players
    local idx = 0
    local index = 0
    local heap
    local groups = {}
    local group,arow
    for i = 1, #players do
        local hand_card = players[i]

        local card = hand_card.card
        
        idx = self:GetIdx(i-1)
        group = CardGroup:create(hand_card,self["player_card"..idx],self["his"..idx],idx,i-1,gui)
        groups[idx] = group
        if self:getCardsNum(hand_card) == 14 then 
            arow = self:GetIdx(i-1)
            self:setArow(arow)
            if arow == 1 then 
                group:setTouchEnable(true)
            end
        end
        self.PlayerHeadList[idx]:setScore(hand_card.score) --TODO
    end
    

    if arow then 
        if arow == 1 then
            arow = 4
        else
            arow = arow - 1
        end
        groups[arow]:setAniPos(self.card_ani_obj)
        self.cur_card_ani:DORestart(true)
    end

    self.groups = groups
    if msg.op then 
        self:setLastOut(msg.op)
        self:OnCall(msg.op)
    end
    self:updateRoomInfo()
    
    if frist and self.data.opt.gui == 2 then 

        self:showFanGui(gui)
    end
    local list = self.playList
    self.playTimer = LuaTimer.Add(0,200,function(id) 
        local fn = list[1]
        if fn then 
            fn()
            table.remove(list,1)
        end
        return true
    end)
end



--上一次出牌的人
function UIRoom:setLastOut(msg)
    local players = self.info.players
    local idx = 0
    
    local val = msg.val
    local op = msg.op
    local index = 0
    local idx = 0
    for i = 1, #players do
        local hand_card = players[i]
        local _idx = self:GetIdx(i-1)
        local his = hand_card.his or {}
        local last = his[#his]
        if last == val then 
            index = _idx
            idx = i - 1
        end
    end
    local group = self.groups[index]
    if not group then return end
    if (op & MJ.OperationResult.Peng) ~= 0 then
        self._lastHisIdx = index
        group:setAniPos(self.card_ani_obj)
    end  
    if (op & MJ.OperationResult.MingGang) ~= 0 then
        self._lastHisIdx = index
        group:setAniPos(self.card_ani_obj)
    end  
    if (op & MJ.OperationResult.DianGang) ~= 0 then
        self._lastHisIdx = index
        group:setAniPos(self.card_ani_obj)
    end  
   
   

   
end
function UIRoom:OnStart(msg)
    if not self._start then 
        self._startData = msg
        return 
    end
    self.data.level = msg.level
        
    self:StartGame(msg,true)
end

--倒计时
function UIRoom:startTimer(play)
    PlayDSound = play
    self:clearTimer()
    local count = 10
    local txt_timer = self.txt_timer
    txt_timer.text = count
    local flag = true
    local num
    self._oldTimerID = LuaTimer.Add(1000,1000,function(id) 
        count = count - 1
        num = count
        if count < 10 then 
            num = "0"..count
        end
        txt_timer.text = num
        if PlayDSound and flag and count <= 4 then
            flag = false
            App.Notice(AppConst.PlaySound,"timeup_alarm")
        end
        return count ~= 0
    end)
end
function UIRoom:clearTimer()
    if self._oldTimerID then
        LuaTimer.Delete(self._oldTimerID)
    end
end

--抽一张卡
function UIRoom:OnDraw(msg)
    if not self._inited then return end
    local that = self
    local fn = function(target,msg) 
        return function() 
            target:_Draw(msg)
        end
    end
    table.insert(self.playList,fn(self,msg))
end
function UIRoom:_Draw(msg)
    if msg.me then 
        msg.idx = self.playerList[1].idx
    end
    local idx = self:GetIdx(msg.idx)
    self:setArow(idx)
    local group = self.groups[idx]
    if not group then return end
    if idx == 1 and msg.val == nil then
        UnityEngine.Debug.LogError("读不到牌id " .. self.idx)
    end
    group:AddCard(msg.val)
    
    if idx == 1 then 
        group:setTouchEnable(true)
    end
    self.info.remain = self.info.remain - 1
    self:updateRoomInfo()
    App.Notice(AppConst.PlaySound,"audio_deal_card")
    
end

function UIRoom:OnCall(msg)
    if not self._inited then return end

    local that = self
    local fn = function(target,msg) 
        return function() 
            target:_Call(msg)
        end
    end
    table.insert(self.playList,fn(self,msg))
    
end

function UIRoom:_Call(msg)
    local val = msg.val
    local op = msg.op
    local idx = msg.idx
    self.btn_hu.gameObject:SetActive(false)
    self.btn_gang.gameObject:SetActive(false)
    self.btn_peng.gameObject:SetActive(false)
    self.lastCall = nil
    local lastCall = {}
    self.lastCallMsg = msg
    lastCall.val = val
    local group = self.groups[1]
    group:setTouchEnable((op & MJ.OperationResult.Play) ~= 0)    
    -- if idx then 
    --     local i = self:GetIdx(idx)
    --     self:setArow(i)
    -- else
    --     self:setArow(1)
    -- end
    if (op & MJ.OperationResult.Play) ~= 0 then
        if not self.isRecord then
            self:setArow(1)
        end
    end  
    if self.isRecord then
        return
    end
   
    if (op & MJ.OperationResult.Peng) ~= 0 then
        self.btn_peng.gameObject:SetActive(true)
        self.game_state:SetActive(true)
    end  
    if (op & MJ.OperationResult.MingGang) ~= 0 then
        self.btn_gang.gameObject:SetActive(true)
        self.game_state:SetActive(true)
        self.lastGangType = MJ.OperationResult.MingGang
    end  
    if (op & MJ.OperationResult.DianGang) ~= 0 then
        self.btn_gang.gameObject:SetActive(true)
        self.game_state:SetActive(true)
        self.lastGangType = MJ.OperationResult.DianGang
    end  
    if (op & MJ.OperationResult.AnGang) ~= 0 then
        self.btn_gang.gameObject:SetActive(true)
        lastCall.val = self.groups[1]:getAnGangVal(val)
        self.game_state:SetActive(true)
        self.lastGangType = MJ.OperationResult.AnGang
    end  
    if (op & MJ.OperationResult.CHI) ~= 0 then
    end  
    if (op & MJ.OperationResult.Hu) ~= 0 then
        self.btn_hu.gameObject:SetActive(true)
        self.game_state:SetActive(true)
    end  
    if (op & MJ.OperationResult.Draw) ~= 0 then
        
    end
    self.lastCall = lastCall
end

--{"uid":10006,"idx":1,"ready":0,"info":{"uid":10006,"name":"3D Coffice","sex":1,"head":"http://wx.qlogo.cn/mmopen/PiajxSqBRaELG3XGBSVEyRSAlU5ibxkXtLHSeicb8z0Xvs15rfQpUVicWdqtw9eic6KkvwDSAsMRYzJ6iahXzibVxgNXA/0","ip":"14.121.176.207"}}
function UIRoom:OnAdd(msg)
    if not self._inited then return end
    self.data.users[msg.idx + 1] = msg
    self:loadUsers()
    -- print("OnAdd")
end

--{idx: 1} 玩家离开
function UIRoom:OnLeave(msg)
    local idx = msg.idx + 1
    self.data.users[idx] = cjson.null
    self:loadUsers()
end



--[[
    MJ.OperationResult = {
    None = 1,
    Play = 2,
    Peng = 4,
    MingGang = 8,
    DianGang = 16,
    AnGang = 32,
    CHI = 64,
    Hu = 128,
    Draw = 256
}
]]

function UIRoom:PlayAni(idx,ani_name)
    -- local prefab = Resources.Load(ani_name)
    local prefab = Utils.ResourceMgr.Instance:LoadGameObject(ani_name,false)
    local obj = MJ.addChild(self["ani_node_"..idx],prefab,false)
    obj.transform.localScale = Vector3.zero
    local tween = obj.transform:DOScale(1.0,0.15)
    Tool.SetEase(tween,DG.Tweening.Ease.OutBounce)
    local group = obj.transform:GetComponent(UnityEngine.CanvasGroup)
    Tool.onComplete(tween,function() 
        local t = group:DOFade(0.0,0.3)
        Tool.SetDelay(t,0.3)
        Tool.onComplete(t,function() 
            Object.Destroy(obj.gameObject)
        end)
    end)
end

function UIRoom:removeHis()
    local lastIdx = self._lastHisIdx
    if lastIdx then 
        local group = self.groups[lastIdx]
        if group then 
            group:RemoveHis()
            self.card_ani_obj.gameObject:SetActive(false)
        end
    end
end

function UIRoom:selectHisCard(data)
    for i = 1,#self.groups do 
        self.groups[i]:selectHisCard(data)
    end
end


--牌局信息
function UIRoom:updateRoomInfo()
    local cardNum = self.info.remain --剩下多少牌
    local cur = self.data.level --当前局
    local max = self.data.maxLevel --共局数
    self.txt_room_info.text = Localization.getText("RoomCardInfo",cardNum,cur,max)
end


local PENG = "ui/room/ani/peng"
local HU = "ui/room/ani/hu"
local GANG = "ui/room/ani/gang"
local AN_GANG = "ui/room/ani/an_gang"
local MING_GANG = "ui/room/ani/ming_gang"
local JIAN = "ui/room/ani/jian"

function UIRoom:_play(msg)
    self.game_state:SetActive(false)
    
    local idx = self:GetIdx(msg.idx)
    local op = msg.op
    local val = msg.val
    local group = self.groups[idx]
    local users = self.data.users
    local sex = users[msg.idx + 1].info.sex
    if idx == 1 then 
        group:setTouchEnable(false)
        PlayDSound = false
    end
    if idx == 1 and not msg.me and not self.isRecord then return end
    
    if op == MJ.OperationResult.None then 
        return
    elseif op == MJ.OperationResult.Play then
        ---防止网络卡
        self._lastHisIdx = idx
        if idx == 1 then 
            group:setTouchEnable(false)
            PlayDSound = false
        end
        group:AddHis(val,self["ani_node_"..idx],self.card_ani_obj,sex)
        self.cur_card_ani:DORestart(true)
    elseif op == MJ.OperationResult.Peng then
        group:CardPeng(val)
        if idx == 1 then 
            group:setTouchEnable(true)
        end
        local sound = "peng"
        self:PlayAni(idx,PENG)
        App.Notice(AppConst.PlaySound,{ sound, sex})
        self:setArow(idx)
        self:removeHis()
    elseif op == MJ.OperationResult.MingGang then
        group:CardMingGang(val)
        local sound = "gang"
        self:PlayAni(idx,MING_GANG)
        App.Notice(AppConst.PlaySound,{ sound, sex})
        self:setArow(idx)
    elseif op == MJ.OperationResult.DianGang then
        group:CardDianGang(val)
        local sound = "gang"
        self:PlayAni(idx,GANG)
        App.Notice(AppConst.PlaySound,{ sound, sex})
        self:setArow(idx)
        self:removeHis()
    elseif op == MJ.OperationResult.AnGang then
        group:CardAnGang(val)
        local sound = "gang"
        self:PlayAni(idx,AN_GANG)
        App.Notice(AppConst.PlaySound,{ sound, sex})
        self:setArow(idx)
    elseif op == MJ.OperationResult.CHI then
    elseif op == MJ.OperationResult.Hu then
        local sound = "hu"
        App.Notice(AppConst.PlaySound,{ sound, sex})
        self:PlayAni(idx,HU)
    elseif op == MJ.OperationResult.Draw then
    elseif op == MJ.OperationResult.Jian then 
        self:setArow(idx)
        self:PlayAni(idx,JIAN)
        local head = self.PlayerHeadList[idx]
        local target = self.PlayerHeadList[self:GetIdx(val)]
        head:showJian(true,target.data.headimgurl)
    end
end

---{"idx":"0","op":2,"val":14,"s":15}
function UIRoom:OnPlay(msg)
    if not self._inited then return end
    if not msg.idx then msg.idx = self.playerList[1].idx end
    local idx = self:GetIdx(msg.idx)
    if idx == 1 and msg.op == MJ.OperationResult.Play then 
        self:_play(msg)
    else
        local fn = function(target,msg) 
            return function() 
                target:_play(msg)
            end
        end
        table.insert(self.playList,fn(self,msg))
    end    
    -- self:_play(msg)
    
end


function UIRoom:OnEnd(msg)
    App.Notice(AppConst.Room_Rule_Hide)
    App.Notice(AppConst.SettingHide)
    if not self._inited then return end
    PlayDSound = false
    self.showResult = true
    self:HideStatus()
    local hu = msg.hu
    if hu and hu ~= cjson.null then 
        local sound = "hu"
        local me = nil
        local users = self.data.users
        for i,v in pairs(hu) do
            if v and v ~= cjson.null then
                local idx = tonumber(i) + 1
                local user = users[idx]
                idx = self:GetIdx(idx-1)
                local sex = user.info.sex
                if idx ~= 1 and not self.isRecord then
                    local cards = msg.cards[tonumber(i) + 1]
                    if self.groups[idx] and cards then
                        self.groups[idx]:ShowHand(cards)
                    end
                end
                self:PlayAni(idx,HU)
                App.Notice(AppConst.PlaySound,{ sound, sex })
            end
        end
        
        App.Notice(AppConst.GameResult_Show,{room_data = self.data,result = msg,info = self.info, showMa = true,time = 300,isRecord = self.isRecord })
       
    else
        App.Notice(AppConst.GameResult_Show,{room_data = self.data,result = msg,info = self.info, showMa = true,time = 0,isRecord = self.isRecord })
    end
    for i = 0,3 do 
        local idx = self:GetIdx(i)
        if idx and msg.score and msg.score.final then
            local score = msg.score.final[i+1]
            if score then 
                self.PlayerHeadList[idx]:setScore(score) --TODO
            end
        end
    end
    local cur = self.data.level --当前局
    local max = self.data.maxLevel --共局数
    if cur >= max then 
        App.Notice(AppConst.Notice_OnRoomClose,{room = 0})
    end
end

function UIRoom:OnReady(msg)
    if not self._inited then 
        return
    end
    
    for i = 0,3 do
        local idx = self:GetIdx(i)
        if idx then
            local fm = "state%d"
            local name = string.format(fm,idx)
            local id = string.format("%d",i)
            local item = self[name]
            local user = self.data.users[i+1]
            if user and not  cjson.null then 
                user.ready = msg[id]
            end
            
            if item then 
                item:SetActive(msg[id] == 1)
                if idx == 1 and msg[id] == 1 then 
                    self.arow_ani.gameObject:SetActive(false)
                    self:NewGame()
                end
            end
        end
    end
end


--玩家在线状态
--{idx:idx, status:status} 1在线 0表示离线
function UIRoom:OnNet(msg)
    if not self._inited then return end
     
    local idx = self:GetIdx(msg.idx)
    if idx == nil or self.PlayerHeadList[idx] == nil then return end
    self.PlayerHeadList[idx]:udpateNet(msg.status)
    local user = self.data.users[msg.idx+1]
    if user and not cjson.null then
        user.ready = msg.status
    end
end

function UIRoom:OnRoomClose(msg)
    self.game_state:SetActive(false)
    if not self._inited then return end
    MJ.player.room = msg.room
    local cur = self.data.level --当前局
    local max = self.data.maxLevel --共局数
    
    if (msg.reason and msg.reason ~= cjson.null and msg.reason ~= 2) or self.showResult then
        return
    end
    if cur >= max then 
        return
    end
    
    App.Notice(AppConst.Room_Hide)
    self._inited = false
end



--显示申请解散窗口
function UIRoom:OnChoose(msg)
    App.Notice(AppConst.GameResult_Hide)
    App.Notice(AppConst.Room_Disband_Show, { users = self.data.users,msg = msg })
end

--解散房间成功
function UIRoom:OnChooseClose(msg)
    App.Notice(AppConst.Room_Disband_Hide)
end

--------------------------------------------------------------------------------------------


---------------------------事件--------------------
function UIRoom:onClick(go,name)
    if name == "btnRule" then 
        App.Notice(AppConst.Room_Rule_Show,self:getRule())
        return
    end
    if not self.lastCall then 
        return
    end
    if name == "btn_hu" then
        self.lastCall.op = MJ.OperationResult.Hu
    elseif name == "btn_gang" then
        self.lastCall.op = self.lastGangType
    elseif name == "btn_peng" then
        self.lastCall.op = MJ.OperationResult.Peng
    elseif name == "btn_guo" then
        self.lastCall.op = MJ.OperationResult.None
    end
    local game_state = self.game_state
    App.Notice(AppConst.ActionOperation,{ self.lastCall,function(result) 
        game_state:SetActive(false)
    end})
end
--------------------------------------------------


function UIRoom:ResetStepStatus()
    self.card_ani_obj.gameObject:SetActive(false)
    for i = 1,#self.groups do 
        self.groups[i]:ResetStepStatus()
    end
    self:_Call(self.lastCallMsg)
end

function UIRoom:SaveStepStatus()
    for i = 1,#self.groups do 
        self.groups[i]:SaveStepStatus()
    end
end

return UIRoom
