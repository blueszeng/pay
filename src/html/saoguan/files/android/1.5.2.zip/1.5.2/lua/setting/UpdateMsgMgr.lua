local M = {}

M["1.3.2"] = "更新成功，本次更新内容如下：\n加快了出牌动画节奏。\n取消了出牌后还提示出牌音效。\n修正了解散房间显示错误bug.\n优化体验\n祝大家游戏愉快！！"
M["1.5.1"] = "更新成功，本次更新内容如下：\n优化包体大小。\n添加了录像前进后退功能。\n修复bug。\n优化体验\n祝大家游戏愉快"
function M.getNew()
    local version = MJ.ClientVersion or "1.0.0"
    return M[version] or ""
end

return M